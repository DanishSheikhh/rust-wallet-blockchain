# Token-Wallet-on-the-ICP-Blockchain
Develop a Rust-based token wallet for the Internet Computer Protocol (ICP) blockchain, supporting basic functionalities such as sending and receiving IRCRC2 tokens. This project should showcase your proficiency with Rust and blockchain principles, ensuring secure and efficient token transactions.
